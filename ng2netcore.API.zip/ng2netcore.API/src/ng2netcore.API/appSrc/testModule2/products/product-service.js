(function(){
    //mod 2 product service.js

})();
