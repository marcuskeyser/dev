(function(){
    //product service.js

})();
