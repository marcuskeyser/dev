(function(){
    //user service.js

})();
