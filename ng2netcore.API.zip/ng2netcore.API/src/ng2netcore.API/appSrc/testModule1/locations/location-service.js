(function(){
  'use strict';
    //location service
})();
