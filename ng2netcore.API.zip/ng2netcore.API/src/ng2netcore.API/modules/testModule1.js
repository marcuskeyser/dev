(function(){
    //app.js

})();

(function(){
  'use strict';
    //location service
})();

(function(){
    //user service.js

})();

(function(){
    //product service.js

})();
