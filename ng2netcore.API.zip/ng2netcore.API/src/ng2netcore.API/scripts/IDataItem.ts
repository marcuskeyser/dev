export interface IDataItem {
    item1: string;
    item2: string;
    item3: string;
}